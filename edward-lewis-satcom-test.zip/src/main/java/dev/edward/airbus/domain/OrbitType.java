package dev.edward.airbus.domain;

public enum OrbitType {
    GEO, MEO, LEO;
}
